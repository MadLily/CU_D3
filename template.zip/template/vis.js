/* ------------------------------------------------------------------
 TEMPLATE
 -------------------------------------------------------------------- */

var w = window.innerWidth,
	h = window.innerHeight;

var svg = d3.select("#vis")
	.append("svg")
	.attr('width',w)
	.attr('height',h);

var circles = svg.selectAll('circle')
	.data([50,100,150])
	.enter()
	.append('circle')
	.attr('cx',function(d,i){
		return (i*300) +250;
	})
	.attr('cy',300)
	.attr('r',function(d){
		return d;
	});


/*var svg = d3.select("#vis")
	.append("svg")
	.attr("width",w)
	.attr("height",h);*/